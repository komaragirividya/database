//RETRIEVING DATA (USING SELECT QUERY)
package datapack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class DataRtrieve
{

	public static void main(String[] args) throws Exception
	
	{
		Class.forName("org.h2.Driver");
		Connection con= DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");  // url,username,password
		Statement stmt=con.createStatement(); //interface
		ResultSet rs =stmt.executeQuery("select * from student");
		
		while (rs.next())     //rs doesnot take increaments
		{
			
			System.out.println(rs.getInt(1)+" | "+rs.getString(2)+" | "+rs.getString(3)+" | "+rs.getInt(4));
		}
		
		PreparedStatement pst=con.prepareStatement("delete from  student  where id=302");
		
		
				
		rs.close();  //close retrieve statement
		stmt.close();     // close Statement
		con.close();    //close connection
		
		
		

	}

}
