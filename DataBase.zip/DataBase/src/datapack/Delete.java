package datapack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Delete
{

	public static void main(String[] args) throws Exception
	
	{
		Class.forName("org.h2.Driver");
		Connection con= DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");  // url,username,password
		
		PreparedStatement pst=con.prepareStatement("delete from  student  where id=302");
		
		
				
		pst.execute();    //execution
		pst.close();     // close PreaparedStatement
		con.close();    //close connection
		
		
		System.out.println("data is deleted");

	}

}
