package datapack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Test
{

	public static void main(String[] args) throws Exception
	
	{
		Class.forName("org.h2.Driver");
		Connection con= DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");  // url,username,password
		PreparedStatement pst=con.prepareStatement("insert into student values(301,'ram','tpt',98765432)");
		
		pst.execute();    //execution
		pst.close();     // close PreaparedStatement
		con.close();    //close connection
		
		
		System.out.println("data is added");

	}

}
